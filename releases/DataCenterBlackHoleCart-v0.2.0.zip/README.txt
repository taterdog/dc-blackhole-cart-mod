Data Center Black-Hole Cart

This package contains the cart mod and its early-start MelonLoader bootstrap.
Both folders are required on Windows and Linux/Proton.

Install

1. Close Data Center.
2. Install MelonLoader 0.7.3 or newer and launch the game once.
3. Merge this package's Mods and Plugins folders into the Data Center game
   folder. Do not copy either folder inside the other.
4. Start Data Center through Steam.

The finished layout includes:

  Data Center/Mods/DataCenterBlackHoleCart.dll
  Data Center/Mods/DataCenterBlackHoleCart.deps.json
  Data Center/Plugins/DataCenterBlackHoleCart.Bootstrap.dll
  Data Center/Plugins/DataCenterBlackHoleCart.Bootstrap.deps.json

The bootstrap repairs the known malformed generated UnityEngine.CoreModule.dll
after MelonLoader regenerates IL2CPP assemblies and before it loads the cart
mod. It uses MelonLoader's existing dependencies; no extra runtime is bundled.

Cart inventory is embedded in Data Center's normal save data and travels with
that save through Steam Cloud. Version 0.2.0 imports older machine-local cart
JSON when a save has no embedded cart record yet. Save the game once after the
import so other computers receive it. The old JSON is retained as recovery
data.

Do that first upgrade and save on the Windows or Linux installation that
actually has the old UserData JSON. Steam never synced the old sidecar, so the
other computer cannot migrate data it did not receive.

Config remains machine-local at:

  Data Center/UserData/DataCenterBlackHoleCart.cfg

Full guide and current release:

  https://github.com/taterdog/dc-blackhole-cart-mod
